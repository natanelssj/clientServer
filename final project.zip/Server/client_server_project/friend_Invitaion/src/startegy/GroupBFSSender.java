package startegy;

import dao.GroupDao;
import dm.Group;
import dm.Person;
import Service.PersonService;
import mainAlgorithm.AlgorithBfsDfsmSearch;
import mainAlgorithm.BFS_Algo;
import mainAlgorithm.DFS_Algo;
import java.util.*;

/**
 * A strategy to perform search over groups using BFS or DFS from the JAR.
 */
public class GroupBFSSender implements ISendStrategy<Group> {
    private final GroupDao groupDao;
    private  PersonService personService;
    private final AlgorithBfsDfsmSearch searchAlgorithm;

    /**
     * Constructor allowing choice between BFS and DFS.
     *
     * @param groupDao      The GroupDao instance.
     * @param personService The PersonService instance.
     * @param useBFS        True to use BFS, false to use DFS.
     */
    public GroupBFSSender(GroupDao groupDao, PersonService personService, boolean useBFS) {
        this.groupDao = groupDao;
        this.personService = personService != null ? personService : new PersonService();  // מבטיח שהוא לא יהיה null
        this.searchAlgorithm = useBFS ? new BFS_Algo() : new DFS_Algo();
    }
    public GroupBFSSender(GroupDao groupDao, boolean useBFS) {
        this.groupDao = groupDao;
        this.personService = personService != null ? personService : new PersonService();  // מבטיח שהוא לא יהיה null
        this.searchAlgorithm = useBFS ? new BFS_Algo() : new DFS_Algo();
    }

    @Override
    public String send() {
        return "";
    }

    @Override
    public List<Group> sendInvitations(int startId, int range) {
        Map<Integer, List<Integer>> groupGraph = buildGroupGraph();
        List<Integer> visitedGroupIds = searchAlgorithm.search(groupGraph, startId, range);
        List<Group> result = new ArrayList<>();
        for (int groupId : visitedGroupIds) {
            Group group = groupDao.find(groupId);
            if (group != null) {
                result.add(group);
            }
        }
        return result;
    }


    public Group findSingleGroupById(int startId, int range) {
        Map<Integer, List<Integer>> groupGraph = buildGroupGraph();
        List<Integer> visitedGroupIds = searchAlgorithm.search(groupGraph, startId, range);
        for (int groupId : visitedGroupIds) {
            Group group = groupDao.find(groupId);
            if (group != null) {
                return group;
            }
        }
        return null;
    }

    private Map<Integer, List<Integer>> buildGroupGraph() {
        List<Person> allPersons = personService.getAllPersons();
        Map<Integer, List<Integer>> groupGraph = new HashMap<>();

        for (Person person : allPersons) {
            Integer groupId = person.getGroupId();
            if (groupId == null) continue;

            groupGraph.computeIfAbsent(groupId, k -> new ArrayList<>());

            for (int connectedId : person.getConnections()) {
                Person connectedPerson = personService.findPersonById(connectedId);
                if (connectedPerson != null) {
                    Integer connectedGroupId = connectedPerson.getGroupId();
                    if (connectedGroupId != null && !connectedGroupId.equals(groupId)) {
                        groupGraph.get(groupId).add(connectedGroupId);
                        groupGraph.computeIfAbsent(connectedGroupId, k -> new ArrayList<>()).add(groupId);
                    }
                }
            }
        }
        return groupGraph;
    }
}