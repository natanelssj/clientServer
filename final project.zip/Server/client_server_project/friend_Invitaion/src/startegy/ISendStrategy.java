package startegy;

import java.util.List;

/**
 * Strategy interface for sending invitations (searching) using different algorithms.
 * @param <T> The type of entity to search (e.g., Group, Person).
 */
public interface ISendStrategy<T> {
    String send(); // Keep for compatibility, though unused here
    List<T> sendInvitations(int startId, int range);
}