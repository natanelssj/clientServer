package startegy;

import dao.PersonDAO;
import dm.Person;
import mainAlgorithm.AlgorithBfsDfsmSearch;
import mainAlgorithm.BFS_Algo;
import mainAlgorithm.DFS_Algo;
import java.util.*;

/**
 * A strategy to perform search over persons using BFS or DFS from the JAR.
 */
public class DFSSender implements ISendStrategy<Person> {
    private final PersonDAO personDao;
    private final AlgorithBfsDfsmSearch searchAlgorithm;

    /**
     * Constructor allowing choice between DFS and BFS.
     *
     * @param personDao The PersonDAO instance.
     * @param useDFS    True to use DFS, false to use BFS.
     */
    public DFSSender(PersonDAO personDao, boolean useDFS) {
        this.personDao = personDao;
        this.searchAlgorithm = useDFS ? new DFS_Algo() : new BFS_Algo();
    }

    @Override
    public String send() {
        return ""; // Unused, kept for compatibility
    }

    @Override
    public List<Person> sendInvitations(int startUserId, int range) {
        Map<Integer, List<Integer>> graph = personDao.getConnectionsGraph();
        List<Integer> visitedIds = searchAlgorithm.search(graph, startUserId, range);
        List<Person> invitedPersons = new ArrayList<>();
        for (int id : visitedIds) {
            Person person = personDao.findById(id);
            if (person != null) {
                invitedPersons.add(person);
            }
        }
        return invitedPersons;
    }
}