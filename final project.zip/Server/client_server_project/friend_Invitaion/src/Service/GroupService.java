package Service;

import dao.GroupDao;
import dm.Group;
import startegy.GroupBFSSender;
import startegy.ISendStrategy;
import java.util.List;
import mainAlgorithm.*;
/**
 * Service class for managing groups with BFS-based search.
 */
public class GroupService {
    private final GroupDao groupDao = new GroupDao();
    private ISendStrategy<Group> sendStrategy;
    private GroupBFSSender startegy;


    public GroupService(PersonService personService) {
        groupDao.loadAll(); // Load existing groups on startup
        sendStrategy = new GroupBFSSender(groupDao, personService,true);
    }

    public void addGroup(Group group) {
        groupDao.save(group);
    }
    // Find groups using BFS
    public List<Group> findGroupById(int startId) {
        return sendStrategy.sendInvitations(startId, 0); // Range fixed at 0
    }
    public Group findGroupByIdSingle(int id) {

        return groupDao.find(id);
    }



    public Group findGroupByIdSingl(int id) {
        startegy=new GroupBFSSender(groupDao,true);
        return startegy.findSingleGroupById(id,3);
    }




    public void deleteGroup(int id) {
        Group group = groupDao.find(id);
        if (group != null) {
            groupDao.delete(group);
        }
    }

    public List<Group> getAllGroups() {
        return groupDao.findAll();
    }
    public void addMemberToGroup(int groupId, int personId) {
        Group group = groupDao.find(groupId);
        if (group != null) {
            group.addMember(personId);
            groupDao.save(group);
        }
    }

    public void removeMemberFromGroup(int groupId, int personId) {
        Group group = groupDao.find(groupId);
        if (group != null) {
            group.removeMember(personId);
            groupDao.save(group);
        }
    }
}