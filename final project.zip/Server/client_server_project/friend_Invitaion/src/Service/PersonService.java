package Service;

import dao.PersonDAO;
import dm.Person;
import startegy.ISendStrategy;
import startegy.DFSSender;

import java.util.List;
import java.util.Map;

public class PersonService {
    private final PersonDAO personDao = new PersonDAO();
    private ISendStrategy<Person> sendStrategy;

    public PersonService() {
        personDao.loadAll();
        personDao.loadConnections();
    }

    public void addPerson(Person person) {
        if (person.getId() == 0) {
            person.setId(personDao.generateNewId());
        }
        personDao.save(person);
    }

    public List<Person> getAllPersons() {
        return personDao.findAll();
    }

    public List<Person> search(int startId) {
        sendStrategy = new DFSSender(personDao,true);// sendStrategy = new DFSSender(personDao,BFS);//
        return sendStrategy.sendInvitations(startId, 3);
    }

    public Person findPersonById(int id) {return personDao.findById(id);}
    public void deletePerson(int id) {
        personDao.delete(id);
    }

    public void addConnection(int personId1, int personId2) {
        personDao.addConnection(personId1, personId2);
    }
}