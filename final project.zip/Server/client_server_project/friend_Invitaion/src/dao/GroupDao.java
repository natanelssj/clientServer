package dao;

import dm.Group;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.util.*;

public class GroupDao implements IDAO<Integer, Group> {
    private final Map<Integer, Group> groupStorage = new HashMap<>();
    private final String filePath = "groups.txt";
    private final Gson gson = new Gson();

    @Override
    public void save(Group entity) {
        groupStorage.put(entity.getId(), entity);
        saveAll();
    }

    @Override
    public Group find(Integer id) {
        return groupStorage.get(id);
    }

    @Override
    public void delete(Group entity) {
        groupStorage.remove(entity.getId());
        saveAll();
    }

    @Override
    public List<Group> findAll() {
        return new ArrayList<>(groupStorage.values());
    }

    @Override
    public void saveAll() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            gson.toJson(groupStorage.values(), writer);
        } catch (IOException e) {
            System.err.println("Failed to save groups: " + e.getMessage());
        }
    }
    @Override
    public void loadAll() {
        File file = new File(filePath);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            Group[] groupsArray = gson.fromJson(reader, Group[].class);
            if (groupsArray != null) {
                groupStorage.clear();
                for (Group group : groupsArray) {
                    if (group != null) {
                        if (group.getMembers() == null) {
                            group.setMembers(new ArrayList<>());
                        }
                        if (group.getMemberCount() == 0 && !group.getMembers().isEmpty()) {
                            group.setMemberCount(group.getMembers().size()); // Sync memberCount with members
                        }
                        groupStorage.put(group.getId(), group);
                    }
                }
                return;
            }

            // If not an array, try parsing as a list of groups
            reader.close(); // Reset reader
            try (BufferedReader newReader = new BufferedReader(new FileReader(filePath))) {
                List<Group> groupsList = gson.fromJson(newReader, new TypeToken<List<Group>>(){}.getType());
                if (groupsList != null) {
                    groupStorage.clear();
                    for (Group group : groupsList) {
                        if (group != null) {
                            groupStorage.put(group.getId(), group);
                        }
                    }
                    return;
                }
            }

            // Try as a single group (for backward compatibility or malformed files)
            reader.close(); // Reset reader
            try (BufferedReader newReader = new BufferedReader(new FileReader(filePath))) {
                Group singleGroup = gson.fromJson(newReader, Group.class);
                if (singleGroup != null) {
                    groupStorage.clear();
                    groupStorage.put(singleGroup.getId(), singleGroup);
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to load groups: " + e.getMessage());
        }
    }
}