package dao;

import dm.Person;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class PersonDAO {
    private final Map<Integer, Person> people = new HashMap<>();
    private final Map<Integer, List<Integer>> connectionsGraph = new HashMap<>();
    private final String PERSONS_FILE = "persons.txt";
    private final String CONNECTIONS_FILE = "connections.txt";
    private final Gson gson = new Gson();

    public void save(Person entity) {
        if (entity.getId() == 0) {
            int newId = generateNewId();
            entity.setId(newId);
        }
        people.put(entity.getId(), entity);
        saveAll();
    }

    public int generateNewId() {
        int maxId = people.keySet().stream().mapToInt(Integer::intValue).max().orElse(0);
        return maxId + 1;
    }

    public Person findById(int id) {
        return people.get(id);
    }

    public List<Person> findAll() {
        return new ArrayList<>(people.values());
    }

    public void delete(int id) {
        people.remove(id);
        connectionsGraph.remove(id);
        for (List<Integer> connections : connectionsGraph.values()) {
            connections.removeIf(connId -> connId == id);
        }
        saveAll();
        saveConnections();
    }

    public void addConnection(int personId1, int personId2) {
        connectionsGraph.computeIfAbsent(personId1, k -> new ArrayList<>()).add(personId2);
        connectionsGraph.computeIfAbsent(personId2, k -> new ArrayList<>()).add(personId1);
        Person p1 = findById(personId1);
        Person p2 = findById(personId2);
        if (p1 != null) p1.addConnection(personId2);
        if (p2 != null) p2.addConnection(personId1);
        saveConnections();
    }

    public Map<Integer, List<Integer>> getConnectionsGraph() {
        return connectionsGraph;
    }

    public void loadAll() {
        File file = new File(PERSONS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(PERSONS_FILE))) {
            List<Person> persons = gson.fromJson(reader, new TypeToken<List<Person>>(){}.getType());
            if (persons != null) {
                people.clear();
                for (Person person : persons) {
                    if (person == null) continue;
                    if (person.getId() == 0) {
                        person.setId(generateNewId());
                    }
                    people.put(person.getId(), person);
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to load persons: " + e.getMessage());
        }
    }

    public void saveAll() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PERSONS_FILE))) {
            gson.toJson(people.values(), writer);
        } catch (IOException e) {
            System.err.println("Failed to save persons: " + e.getMessage());
        }
    }

    public void loadConnections() {
        File file = new File(CONNECTIONS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(CONNECTIONS_FILE))) {
            Map<Integer, List<Integer>> loadedConnections = gson.fromJson(reader, new TypeToken<Map<Integer, List<Integer>>>(){}.getType());
            if (loadedConnections != null) {
                connectionsGraph.clear();
                connectionsGraph.putAll(loadedConnections);
                // Update Person objects with connections
                for (Map.Entry<Integer, List<Integer>> entry : connectionsGraph.entrySet()) {
                    Person person = findById(entry.getKey());
                    if (person != null) {
                        person.setConnections(entry.getValue());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to load connections: " + e.getMessage());
        }
    }

    public void saveConnections() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CONNECTIONS_FILE))) {
            gson.toJson(connectionsGraph, writer);
        } catch (IOException e) {
            System.err.println("Failed to save connections: " + e.getMessage());
        }
    }

    public List<Person> findByGroupId(int groupId) {
        return people.values().stream()
                .filter(p -> p.getGroupId() != null && p.getGroupId() == groupId)
                .collect(Collectors.toList());
    }
}