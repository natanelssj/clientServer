package dm;

import java.util.ArrayList;
import java.util.List;

public class Group {
    private Integer id;
    private String name;
    private List<Integer> members = new ArrayList<>(); // שמור את זה לצורך ניהול פנימי, אבל לא נציג את זה ב-UI
    private int memberCount = 0; // שדה שיחזיק את מספר המשתתפים

    // בנאים (Constructors)
    public Group(Integer id, String name) {
        this.id = id != null ? id : 0;
        this.name = name;
        this.members = new ArrayList<>();
        this.memberCount = 0; // ברירת מחדל: 0 משתתפים
    }

    public Group(String name) {
        this(0, name);
    }

    // Getters ו-Setters
    public Integer getId() {
        return id != null ? id : 0;
    }

    public void setId(Integer id) {
        this.id = id != null ? id : 0;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<Integer> getMembers() {
        return members != null ? members : new ArrayList<>();
    }

    public void setMembers(List<Integer> members) {
        this.members = members != null ? members : new ArrayList<>();
        this.memberCount = this.members.size(); // סנכרן memberCount עם גודל הרשימה
    }

    public int getMemberCount() { return memberCount; } // גט למספר המשתתפים
    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount >= 0 ? memberCount : 0; // ודא שמספר המשתתפים לא שלילי
    }

    // שיטות לניהול משתתפים
    public void addMember(int personId) {
        if (!members.contains(personId)) {
            members.add(personId);
            memberCount++; // הגדל את מספר המשתתפים
        }
    }

    public void removeMember(int personId) {
        if (members.contains(personId)) {
            members.remove(Integer.valueOf(personId));
            memberCount--; // הפחת את מספר המשתתפים
            if (memberCount < 0) memberCount = 0; // מנע מספר שלילי
        }
    }

    @Override
    public String toString() {
        return "Group{id=" + id + ", name='" + name + "', members=" + members + ", memberCount=" + memberCount + "}";
    }
}