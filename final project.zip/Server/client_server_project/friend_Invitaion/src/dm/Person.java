package dm;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private Integer id;
    private String name;
    private Integer groupId;
    private Group groupName;
    private List<Integer> connections = new ArrayList<>(); // List of connected person IDs

    // Constructors
    public Person(Integer id, String name) {
        this.id = id != null ? id : 0;
        this.name = name;
    }

    public Person(Integer id, String name, Integer groupId) {
        this.id = id != null ? id : 0;
        this.name = name;
        this.groupId = groupId;
    }

    public int getId() {
        if (id == null) {
            System.err.println("Warning: Person ID is null, defaulting to 0. Check data integrity.");
            return 0;
        }
        return id.intValue();
    }

    public void setId(Integer id) {
        this.id = id != null ? id : 0;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getGroupId() { return groupId; }
    public void setGroupId(Integer groupId) { this.groupId = groupId; }
    public Group getGroupName() { return groupName; }
    public void setGroupName(Group groupName) { this.groupName = groupName; }

    public List<Integer> getConnections() {
        return connections != null ? connections : new ArrayList<>();
    }

    public void setConnections(List<Integer> connections) {
        this.connections = connections != null ? connections : new ArrayList<>();
    }

    public void addConnection(int personId) {
        if (connections == null) {
            connections = new ArrayList<>();
        }
        if (!connections.contains(personId)) {
            connections.add(personId);
        }
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", groupId=" + groupId +
                ", groupName='" + (groupName != null ? groupName.getName() : "none") + '\'' +
                ", connections=" + connections +
                '}';
    }
}