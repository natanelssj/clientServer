package controller;

import Service.PersonService;
import dm.Person;
import com.google.gson.Gson;
import server.Request;
import server.Response;

import java.util.List;
import java.util.Map;

public class PersonController {
    private static final PersonService personService = new PersonService();
    private static final Gson gson = new Gson();

    // Add a person (e.g., {"headers": {"action": "person/add"}, "body": {"id": 1, "name": "Alice", "groupId": 1}})
// In PersonController.addPerson
// In PersonController.addPerson
    public static Response addPerson(Request request) {
        Map<String, Object> body = request.getBody();
        String bodyJson = gson.toJson(body);
        Person person = gson.fromJson(bodyJson, Person.class); // Server-side dm.Person
        personService.addPerson(person);

        return new Response("OK", "Person added: " + person.getName(), person);
    }    // Delete a person (e.g., {"headers": {"action": "person/delete"}, "body": {"id": 1}})
    public static Response deletePerson(Request request) {
        Map<String, Object> body = request.getBody();
        int id = ((Double) body.get("id")).intValue();
        personService.deletePerson(id);
        return new Response("OK", "Person deleted: " + id);
    }

    // Find a person by ID (e.g., {"headers": {"action": "person/get"}, "body": {"id": 1}})
    public static Response findPersonById(Request request) {
        Map<String, Object> body = request.getBody();
        int id = ((Double) body.get("id")).intValue();
        Person person = personService.findPersonById(id);
        if (person != null) {
            return new Response("OK", "Person found", person);
        } else {
            return new Response("ERROR", "Person not found");
        }
    }

    // List all persons (e.g., {"headers": {"action": "person/getAll"}, "body": {}})
    public static Response getAllPersons(Request request) {
        List<Person> persons = personService.getAllPersons();
        return new Response("OK", "All persons retrieved", persons);
    }

    // Add a connection (e.g., {"headers": {"action": "person/addConnection"}, "body": {"personId1": 1, "personId2": 2}})
    public static Response addConnection(Request request) {
        Map<String, Object> body = request.getBody();
        int personId1 = ((Double) body.get("personId1")).intValue();
        int personId2 = ((Double) body.get("personId2")).intValue();
        personService.addConnection(personId1, personId2);
        return new Response("OK", "Connection added: " + personId1 + " <-> " + personId2);
    }

    // Search using DFS (e.g., {"headers": {"action": "person/search"}, "body": {"id": 1, "name": "natan", "groupId": 2, "groupName": "Developers", "connections": [3, 4]}})
    public static Response search(Request request) {
        Map<String, Object> body = request.getBody();
        String bodyJson = gson.toJson(body);
        Person searchPerson = gson.fromJson(bodyJson, Person.class);
        int startId = searchPerson.getId();
        List<Person> result = personService.search(startId); // Default to DFS
        return new Response("OK", "Search completed", result);
    }

}