package controller;

import Service.GroupService;
import Service.PersonService;
import dm.Group;
import com.google.gson.Gson;
import server.Request;
import server.Response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupController {
    private static final GroupService groupService;
    private static final Gson gson = new Gson();

    // Initialize GroupService with PersonService dependency
    static {
        PersonService personService = new PersonService();
        groupService = new GroupService(personService);
    }

    // Add a group (e.g., {"headers": {"action": "group/add"}, "body": {"id": 1, "name": "Developers"}})
// In GroupController.addGroup
    public static Response addGroup(Request request) {
        Map<String, Object> body = request.getBody();
        String bodyJson = gson.toJson(body);
        Group group = gson.fromJson(bodyJson, Group.class);
        groupService.addGroup(group);
        return new Response("OK", "Group added: " + group.getName(), group); // Returns memberCount as 0
    }

    public static Response getAllGroups(Request request) {
        List<Group> groups = groupService.getAllGroups();
        List<Map<String, Object>> responseData = groups.stream().map(group -> {
            Map<String, Object> groupData = new HashMap<>();
            groupData.put("id", group.getId());
            groupData.put("name", group.getName());
            groupData.put("numberMembers", group.getMemberCount()); // Return member count
            return groupData;
        }).collect(Collectors.toList());
        return new Response("OK", "All groups retrieved", responseData);
    }

    public static Response findGroupById(Request request) {
        Map<String, Object> body = request.getBody();
        int startId = ((Double) body.get("id")).intValue();
        Group group = groupService.findGroupByIdSingl(startId); // Use single-group lookup
        if (group != null) {
            Map<String, Object> groupData = new HashMap<>();
            groupData.put("id", group.getId());
            groupData.put("name", group.getName());
            groupData.put("numberMembers", group.getMemberCount());
            return new Response("OK", "Group found", groupData);
        } else {
            return new Response("ERROR", "Group not found with ID: " + startId);
        }
    }
    // Delete a group (e.g., {"headers": {"action": "group/delete"}, "body": {"id": 1}})
    public static Response deleteGroup(Request request) {
        Map<String, Object> body = request.getBody();
        int id = ((Double) body.get("id")).intValue();
        groupService.deleteGroup(id);
        return new Response("OK", "Group deleted: " + id);
    }
    public static Response addMemberToGroup(Request request) {
        Map<String, Object> body = request.getBody();
        int groupId = ((Double) body.get("groupId")).intValue();
        int personId = ((Double) body.get("personId")).intValue();
        groupService.addMemberToGroup(groupId, personId);
        return new Response("OK", "חבר נוסף לקבוצה " + groupId);
    }

    public static Response updateMemberCount(Request request) {
        Map<String, Object> body = request.getBody();
        int groupId = ((Double) body.get("groupId")).intValue();
        int delta = ((Double) body.get("delta")).intValue(); // חיובי להגדלה, שלילי להקטנה

        Group group = groupService.findGroupByIdSingl(groupId);
        if (group != null) {
            int newCount = group.getMemberCount() + delta;
            group.setMemberCount(newCount);
            groupService.addGroup(group); // שמור את הקבוצה המעודכנת
            return new Response("OK", "קבוצה עודכנה: מספר החברים " + newCount, null);
        }
        return new Response("ERROR", "קבוצה לא נמצאה");
    }    // List all groups (e.g., {"headers": {"action": "group/getAll"}, "body": {}})

}