package server;

import com.google.gson.Gson;
import controller.GroupController;
import controller.PersonController;
import server.Request;
import server.Response;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class HandleRequest implements Runnable {
    private Socket socket;
    private Gson gson = new Gson();

    public HandleRequest(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (
                ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream input = new ObjectInputStream(socket.getInputStream())
        ) {
            output.writeObject("Connected to server");
            output.flush();

            String jsonRequest = (String) input.readObject();
            System.out.println("Server received: " + jsonRequest);

            Request request;
            try {
                request = gson.fromJson(jsonRequest, Request.class);
            } catch (com.google.gson.JsonSyntaxException e) {
                output.writeObject(gson.toJson(new Response("ERROR", "Invalid JSON format")));
                return;
            }

            Response response = dispatchRequest(request);
            output.writeObject(gson.toJson(response));
            output.flush();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Response dispatchRequest(Request request) {
        String action = request.getAction();
        if (action == null) {
            return new Response("ERROR", "No action specified in headers");
        }

        switch (action) {
            case "group/add": return GroupController.addGroup(request);
            case "group/getAll": return GroupController.getAllGroups(request);
            case "group/get": return GroupController.findGroupById(request);
            case "group/delete": return GroupController.deleteGroup(request);
            case "group/addMember": return GroupController.addMemberToGroup(request);
            case "group/updateMemberCount": return GroupController.updateMemberCount(request);

            // Person Actions
            case "person/add": return PersonController.addPerson(request);
            case "person/delete": return PersonController.deletePerson(request);
            case "person/get": return PersonController.findPersonById(request);
            case "person/getAll": return PersonController.getAllPersons(request);
            case "person/addConnection": return PersonController.addConnection(request);
            case "person/search": return PersonController.search(request);
            default:
                return new Response("ERROR", "Unknown action: " + action);
        }
    }
}