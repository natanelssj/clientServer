package server;

import com.google.gson.Gson;
import java.util.HashMap;
import java.util.Map;

public class Request {
    private Map<String, String> headers;
    private Map<String, Object> body;

    public Request() {
        // Default constructor for Gson
    }

    public Request(Map<String, String> headers, Map<String, Object> body) {
        this.headers = headers != null ? headers : new HashMap<>();
        this.body = body != null ? body : new HashMap<>();
    }

    public Map<String, String> getHeaders() {
        return headers != null ? headers : new HashMap<>();
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers != null ? headers : new HashMap<>();
    }

    public Map<String, Object> getBody() {
        return body != null ? body : new HashMap<>();
    }

    public void setBody(Map<String, Object> body) {
        this.body = body != null ? body : new HashMap<>();
    }

    public String getAction() {
        return headers != null ? headers.get("action") : null;
    }

    public String toJson() {
        return new Gson().toJson(this);
    }

    public static Request fromJson(String json) {
        return new Gson().fromJson(json, Request.class);
    }
}