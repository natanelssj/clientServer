module com.example.client {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires com.google.gson; // ✅ Add this line

    opens com.example.client to javafx.fxml, com.google.gson;
    exports com.example.client;
}