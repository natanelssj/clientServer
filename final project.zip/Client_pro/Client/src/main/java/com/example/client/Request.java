package com.example.client;

import com.google.gson.Gson;
import java.util.HashMap;
import java.util.Map;

public class Request {
    private Map<String, String> headers; // Now holds "action" and other headers
    private Map<String, Object> body;

    public Request() {
        // Default constructor for Gson
    }

    public Request(Map<String, String> headers, Map<String, Object> body) {
        this.headers = headers;
        this.body = body;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public Map<String, Object> getBody() {
        return body;
    }

    public void setBody(Map<String, Object> body) {
        this.body = body;
    }

    public String getAction() {
        return headers != null ? headers.get("action") : null;
    }

    public String toJson() {
        return new Gson().toJson(this);
    }

    public static Request fromJson(String json) {
        return new Gson().fromJson(json, Request.class);
    }
}