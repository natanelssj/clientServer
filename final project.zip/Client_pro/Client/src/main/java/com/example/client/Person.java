package com.example.client;

import javafx.beans.property.*;
import javafx.collections.FXCollections;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private final IntegerProperty id;
    private final StringProperty name;
    private final StringProperty group;
    private List<String> connections = new ArrayList<>(); // List of connected person IDs
    private Integer groupId=0;
    public Person(int id, String name, String group) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
        this.group = new SimpleStringProperty(group);
        this.groupId = null;
    }
    public int getId() { return id.get(); }
    public String getName() { return name.get(); }
    public String getGroup() { return group.get(); }
    public List<String> getConnections() {
        return connections != null ? connections : new ArrayList<>();
    }
    public Integer getGroupId() { return groupId; } // New getter for groupId
    public IntegerProperty idProperty() { return id; }
    public StringProperty nameProperty() { return name; }
    public StringProperty groupProperty() { return group; }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", groupName='" + groupProperty() + '\'' +
                ", connections=" + connections +
                ", groupId=" + groupId +
                '}';
    }

    public void setConnections(List<String> connections) {
        this.connections = connections != null ? connections : new ArrayList<>();
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
        // Optionally update group name based on groupId
        if (groupId != null && groupId > 0) {
            String groupName = getGroupNameFromServer(groupId); // Implement this method or fetch via server
            this.group.set(groupName != null ? groupName : "Unknown");
        } else {
            this.group.set("Unknown");
        }
    }

    private String getGroupNameFromServer(int groupId) {
        // Implement this to call getGroupName(groupId) from HelloController or server
        return null; // Placeholder
    }
}