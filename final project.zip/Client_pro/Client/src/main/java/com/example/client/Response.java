package com.example.client;

import com.google.gson.Gson;

public class Response {
    private String status;
    private String message;
    private Object data;

    // Constructors, getters, setters, and toJson/fromJson methods using Gson
    public Response(String status, String message) {
        this.status = status;
        this.message = message;
        this.data = null;
    }

    public Response(String status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public Object getData() { return data; }

    public String toJson() {
        return new Gson().toJson(this);
    }

    public static Response fromJson(String json) {
        return new Gson().fromJson(json, Response.class);
    }
}