package com.example.client;

import com.google.gson.*;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HelloController {
    public Button searchButton;
    @FXML private VBox mainMenu;
    @FXML private VBox managerSection;
    @FXML private VBox userSection;

    // Person UI elements
    @FXML private TableView<Person> tableView;
    @FXML private TableColumn<Person, Integer> idColumn;
    @FXML private TableColumn<Person, String> nameColumn;
    @FXML private TableColumn<Person, String> groupColumn;
    @FXML private TextField personIdField;
    @FXML private TextField personNameField;
    @FXML private TextField personGroupIdField;
    @FXML private TextField personIdField1;
    @FXML private TextField personNameField1;
    @FXML private TextField personIdField2;
    @FXML private TextField personNameField2;

    // Group UI elements
    @FXML private TableView<Group> tableViewgroup;
    @FXML private TableColumn<Group, Integer> idgroupColumn;
    @FXML private TableColumn<Group, String> GroupnameColumn;
    @FXML private TableColumn<Group, String> GroupMemberColumn;
    @FXML private TextField groupIdField;
    @FXML private TextField groupNameField;

    // Buttons from main menu
    private String showErr = "Invalid Input";

    private String SERVER_IP = "127.0.0.1";
    private Integer SERVER_PORT = 12345;
    private ObservableList<Person> personData = FXCollections.observableArrayList();
    private ObservableList<Group> groupData = FXCollections.observableArrayList();
    private Gson gson = createGsonWithJavaFXAdapters();
    private boolean isManagerMode = false;

    // Custom Gson builder with type adapters for JavaFX properties
    private Gson createGsonWithJavaFXAdapters() {
        GsonBuilder gsonBuilder = new GsonBuilder();

        // Type adapter for IntegerProperty
        gsonBuilder.registerTypeAdapter(IntegerProperty.class, new JsonDeserializer<IntegerProperty>() {
            @Override
            public IntegerProperty deserialize(JsonElement json, java.lang.reflect.Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                int value = json.getAsInt();
                return new SimpleIntegerProperty(value);
            }
        });

        // Type adapter for StringProperty
        gsonBuilder.registerTypeAdapter(StringProperty.class, new JsonDeserializer<StringProperty>() {
            @Override
            public StringProperty deserialize(JsonElement json, java.lang.reflect.Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                String value = json.getAsString();
                return new SimpleStringProperty(value);
            }
        });

        // Type adapter for ListProperty<String>
        gsonBuilder.registerTypeAdapter(ListProperty.class, new JsonDeserializer<ListProperty<String>>() {
            @Override
            public ListProperty<String> deserialize(JsonElement json, java.lang.reflect.Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                List<String> list = context.deserialize(json, List.class);
                return new SimpleListProperty<>(FXCollections.observableArrayList(list));
            }
        });

        return gsonBuilder.create();
    }

    @FXML
    public void initialize() {
        // Person TableView
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        groupColumn.setCellValueFactory(cellData -> cellData.getValue().groupProperty());

        tableView.setItems(personData);

        // Group TableView
        idgroupColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        GroupnameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        GroupMemberColumn.setCellValueFactory(cellData -> {
            int memberCount = cellData.getValue().getMemberCount();
            return new SimpleStringProperty(String.valueOf(memberCount)); // הצג רק את מספר המשתתפים
        });
        tableViewgroup.setItems(groupData);
    }

    private Response sendToServer(Request request) {
        try {
            Socket socket = new Socket(SERVER_IP, SERVER_PORT);
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            String serverMessage = (String) input.readObject();
            System.out.println("Message from server: " + serverMessage);
            String jsonRequest = request.toJson();
            System.out.println("Sending request: " + jsonRequest);
            output.writeObject(jsonRequest);
            output.flush();
            String jsonResponse;
            try {
                jsonResponse = (String) input.readObject();
                System.out.println("Response from server: " + jsonResponse);
            } catch (EOFException e) {
                System.err.println("Server connection closed unexpectedly: " + e.getMessage());
                output.close();
                input.close();
                socket.close();
                return new Response("ERROR", "Server connection closed unexpectedly", null);
            }
            Response response = Response.fromJson(jsonResponse);
            output.close();
            input.close();
            socket.close();
            return response;
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("IOException: " + e.getMessage() + " - Is the server running at " + SERVER_IP + ":" + SERVER_PORT + "?");
            return new Response("ERROR", "Server connection failed: " + e.getMessage(), null);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return new Response("ERROR", "Invalid server response format: " + e.getMessage(), null);
        }
    }

    @FXML
    private void handleAdd() {
        if (isManagerMode) {
            String name = groupNameField.getText().trim();
            String idText = groupIdField.getText().trim();
            if (!name.isEmpty() && !idText.isEmpty()) {
                try {
                    int id = Integer.parseInt(idText);
                    Map<String, Object> body = new HashMap<>();
                    body.put("id", id);
                    body.put("name", name);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("action", "group/add");
                    Request request = new Request(headers, body);
                    Response response = sendToServer(request);
                    if ("OK".equals(response.getStatus())) {
                        String json = gson.toJson(response.getData());
                        Group addedGroup = gson.fromJson(json, Group.class);
                        if (addedGroup != null) {
                            addedGroup.setMemberCount(0); // Set member count to 0 for a new group
                            groupData.add(addedGroup);
                        } else {
                            groupData.add(new Group(id, name)); // Fallback, start with 0 members
                            Group fallbackGroup = groupData.get(groupData.size() - 1);
                            fallbackGroup.setMemberCount(0); // Set member count to 0
                        }
                        groupIdField.clear();
                        groupNameField.clear();
                    } else {
                        showError(showErr, response.getMessage());
                    }
                } catch (NumberFormatException e) {
                    showError(showErr, "Group ID must be a number.");
                }
            } else {
                showError(showErr, "Enter both ID and name for the group.");
            }
        } else {
            String name = personNameField.getText().trim();
            String idText = personIdField.getText().trim();
            String groupIdText = personGroupIdField.getText().trim();
            if (!name.isEmpty() && !idText.isEmpty() && !groupIdText.isEmpty()) {
                try {
                    int id = Integer.parseInt(idText);
                    int groupId = Integer.parseInt(groupIdText);
                    Map<String, Object> body = new HashMap<>();
                    body.put("id", id);
                    body.put("name", name);
                    body.put("groupId", groupId);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("action", "person/add");
                    Request request = new Request(headers, body);
                    Response response = sendToServer(request);
                    if ("OK".equals(response.getStatus())) {
                        String json = gson.toJson(response.getData());
                        Person addedPerson = gson.fromJson(json, Person.class);
                        if (addedPerson != null) {
                            // Fetch group name based on groupId from the server
                            String groupName = getGroupName(groupId);
                            List<String> connectedNames = getConnectedPersonNames(addedPerson.getId());
                            personData.add(new Person(
                                    addedPerson.getId(),
                                    addedPerson.getName(),
                                    groupName != null ? groupName : "Unknown"
                            ));
                            personData.get(personData.size() - 1).setConnections(connectedNames);

                            // Update group member count on the server
                            updateGroupMemberCount(groupId, 1); // Increment count for this group
                        } else {
                            String groupName = getGroupName(groupId);
                            personData.add(new Person(id, name, groupName != null ? groupName : "Group " + groupId));
                            List<String> connectedNames = getConnectedPersonNames(id);
                            personData.get(personData.size() - 1).setConnections(connectedNames);

                            // Update group member count on the server
                            updateGroupMemberCount(groupId, 1); // Increment count for this group
                        }
                        personIdField.clear();
                        personNameField.clear();
                        personGroupIdField.clear();
                    } else {
                        showError(showErr, response.getMessage());
                    }
                } catch (NumberFormatException e) {
                    showError(showErr, "ID and Group ID must be numbers.");
                }
            } else {
                showError(showErr, "Enter ID, name, and group ID for the person.");
            }
        }
    }

    @FXML
    private void handleRemove() {
        if (isManagerMode) {
            Group selectedGroup = tableViewgroup.getSelectionModel().getSelectedItem();
            if (selectedGroup != null) {
                Map<String, Object> body = new HashMap<>();
                body.put("id", selectedGroup.getId());
                Map<String, String> headers = new HashMap<>();
                headers.put("action", "group/delete");
                Request request = new Request(headers, body);
                Response response = sendToServer(request);
                if ("OK".equals(response.getStatus())) {
                    groupData.remove(selectedGroup);
                } else {
                    showError(showErr, response.getMessage());
                }
            } else {
                showError("Invalid Choice", "Select a group to remove.");
            }
        } else {
            Person selectedPerson = tableView.getSelectionModel().getSelectedItem();
            if (selectedPerson != null) {
                Map<String, Object> body = new HashMap<>();
                body.put("id", selectedPerson.getId());
                Map<String, String> headers = new HashMap<>();
                headers.put("action", "person/delete");
                Request request = new Request(headers, body);
                Response response = sendToServer(request);
                if ("OK".equals(response.getStatus())) {
                    Integer groupId = selectedPerson.getGroupId();
                    if (groupId != null && groupId != 0) {
                        updateGroupMemberCount(groupId, -1); // Decrease count for this group
                    }
                    personData.remove(selectedPerson);
                } else {
                    showError(showErr, response.getMessage());
                }
            } else {
                showError("Invalid Choice", "Select a person to remove.");
            }
        }
    }

    @FXML
    private void handleSearch() {
        if (isManagerMode) {
            String idText = groupIdField.getText().trim();
            String name = groupNameField.getText().trim();
            Map<String, Object> body = new HashMap<>();
            if (!idText.isEmpty()) {
                try {
                    int id = Integer.parseInt(idText);
                    body.put("id", id);
                } catch (NumberFormatException e) {
                    if (name.isEmpty()) {
                        showError(showErr, "Input ID or Name");
                        return;
                    }
                }
            }
            if (!name.isEmpty()) {
                body.put("name", name);
            }
            if (body.isEmpty()) {
                showError(showErr, "Input ID or Name");
                return;
            }
            Map<String, String> headers = new HashMap<>();
            headers.put("action", "group/get");
            Request request = new Request(headers, body);
            Response response = sendToServer(request);
            if ("OK".equals(response.getStatus()) && response.getData() != null) {
                // Handle the response as a single Group object
                String json = gson.toJson(response.getData());
                Map<String, Object> groupDataMap = gson.fromJson(json, Map.class); // Parse as Map first
                int id = ((Double) groupDataMap.get("id")).intValue();
                String groupName = (String) groupDataMap.get("name");
                int numberMembers = ((Double) groupDataMap.get("numberMembers")).intValue();

                // Create a new Group object
                Group group = new Group(id, groupName);
                group.setMemberCount(numberMembers);

                // Update the UI
                this.groupData.clear(); // Clear existing data
                this.groupData.add(group); // Add the single group
                groupIdField.clear();
                groupNameField.clear();
            } else {
                showError("Error", response.getMessage());
            }
        } else {
            // Person search logic
            String idText = personIdField.getText().trim();
            String name = personNameField.getText().trim();
            Map<String, Object> body = new HashMap<>();
            if (!idText.isEmpty()) {
                try {
                    int id = Integer.parseInt(idText);
                    body.put("id", id);
                } catch (NumberFormatException e) {
                    if (name.isEmpty()) {
                        showError("Invalid Input", "Invalid ID.");
                        return;
                    }
                }
            }
            if (!name.isEmpty()) {
                body.put("name", name);
            }
            Map<String, String> headers = new HashMap<>();
            headers.put("action", "person/search");
            Request request = new Request(headers, body);
            Response response = sendToServer(request);
            if ("OK".equals(response.getStatus()) && response.getData() != null) {
                String json = gson.toJson(response.getData());
                List<Map<String, Object>> serverPersons = gson.fromJson(json, List.class); // Parse as List<Map<String, Object>>
                personData.clear();
                for (Map<String, Object> sp : serverPersons) {
                    int id = ((Double) sp.get("id")).intValue();
                    String personName = (String) sp.get("name");
                    int groupId = ((Double) sp.get("groupId")).intValue();
                    // Fetch group name using groupId
                    String groupName = getGroupName(groupId);
                    // Fetch connected persons' names
                    List<String> connectedNames = getConnectedPersonNames(id);
                    personData.add(new Person(id, personName, groupName != null ? groupName : "Unknown"));
                    personData.get(personData.size() - 1).setConnections(connectedNames);
                }
                personIdField.clear();
                personNameField.clear();
                personGroupIdField.clear();
            } else {
                showError("Error", response.getMessage());
            }
        }
    }
    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML private void userEnter() {
        isManagerMode = false;
        userSection.setVisible(true);
        userSection.setManaged(true);
        managerSection.setVisible(false);
        managerSection.setManaged(false);
        mainMenu.setVisible(false);
        mainMenu.setManaged(false);
        System.out.println("User view activated.");
    }

    @FXML private void managerEnter() {
        isManagerMode = true;
        managerSection.setVisible(true);
        managerSection.setManaged(true);
        userSection.setVisible(false);
        userSection.setManaged(false);
        mainMenu.setVisible(false);
        mainMenu.setManaged(false);
        System.out.println("Manager view activated.");
    }

    @FXML private void backToMain() {
        isManagerMode = false;
        mainMenu.setVisible(true);
        mainMenu.setManaged(true);
        managerSection.setVisible(false);
        managerSection.setManaged(false);
        userSection.setVisible(false);
        userSection.setManaged(false);
    }

    @FXML public void handleAddPerson(ActionEvent actionEvent) {
        isManagerMode = false;
        handleAdd();
    }

    @FXML public void handleRemovePerson(ActionEvent actionEvent) {
        isManagerMode = false;
        handleRemove();
    }

    @FXML public void handleSearchPerson(ActionEvent actionEvent) {
        isManagerMode = false;
        handleSearch();
    }

    @FXML public void handleSearchGroup(ActionEvent actionEvent) {
        isManagerMode = true;
        handleSearch();
    }

    @FXML public void handleRemoveGroup(ActionEvent actionEvent) {
        isManagerMode = true;
        handleRemove();
    }

    @FXML
    public void addConnection(ActionEvent actionEvent) {
        String id1Text = personIdField1.getText().trim();
        String id2Text = personIdField2.getText().trim();
        if (!id1Text.isEmpty() && !id2Text.isEmpty()) {
            try {
                int personId1 = Integer.parseInt(id1Text);
                int personId2 = Integer.parseInt(id2Text);
                Map<String, Object> body = new HashMap<>();
                body.put("personId1", personId1);
                body.put("personId2", personId2);
                Map<String, String> headers = new HashMap<>();
                headers.put("action", "person/addConnection");
                Request request = new Request(headers, body);
                Response response = sendToServer(request);
                if ("OK".equals(response.getStatus())) {
                    System.out.println("Connection added between " + personId1 + " and " + personId2);
                    personIdField1.clear();
                    personNameField1.clear();
                    personIdField2.clear();
                    personNameField2.clear();
                } else {
                    showError("Error", response.getMessage());
                }
            } catch (NumberFormatException e) {
                showError(showErr, "Both IDs must be numbers.");
            }
        } else {
            showError(showErr, "Enter IDs for both persons.");
        }
    }
    private String getGroupName(int groupId) {
        Map<String, Object> body = new HashMap<>();
        body.put("id", groupId);
        Map<String, String> headers = new HashMap<>();
        headers.put("action", "group/get");
        Request request = new Request(headers, body);
        Response response = sendToServer(request);
        if ("OK".equals(response.getStatus()) && response.getData() != null) {
            // Parse the response as a Map<String, Object> (single group)
            String json = gson.toJson(response.getData());
            Map<String, Object> groupData = gson.fromJson(json, Map.class);
            int id = ((Double) groupData.get("id")).intValue();
            if (id == groupId) {
                return (String) groupData.get("name");
            }
        }
        return null; // Return null if not found or groupId doesn’t match
    }

    private List<String> getConnectedPersonNames(int personId) {
        System.out.println("Fetching connections for person ID: " + personId);
        Map<String, Object> body = new HashMap<>();
        body.put("id", personId);
        Map<String, String> headers = new HashMap<>();
        headers.put("action", "person/search");
        Request request = new Request(headers, body);
        Response response = sendToServer(request);
        List<String> connectedNames = new ArrayList<>();
        if ("OK".equals(response.getStatus()) && response.getData() != null) {
            String json = gson.toJson(response.getData());
            List<Map<String, Object>> serverPersons = gson.fromJson(json, List.class); // Parse as List<Map<String, Object>>
            System.out.println("Server persons response: " + serverPersons);
            for (Map<String, Object> person : serverPersons) {
                int id = ((Double) person.get("id")).intValue();
                List<Integer> connections = (List<Integer>) person.get("connections");
                System.out.println("Person ID: " + id + ", Connections: " + connections);
                if (connections != null && connections.contains(personId)) {
                    connectedNames.add((String) person.get("name"));
                }
            }
        }
        System.out.println("Connected names for person " + personId + ": " + connectedNames);
        return connectedNames;
    }
    private void updateGroupMemberCount(int groupId, int delta) {
        Map<String, Object> body = new HashMap<>();
        body.put("groupId", groupId);
        body.put("delta", delta); // Positive to increment, negative to decrement
        Map<String, String> headers = new HashMap<>();
        headers.put("action", "group/updateMemberCount");
        Request request = new Request(headers, body);
        Response response = sendToServer(request);
        if (!"OK".equals(response.getStatus())) {
            showError("Error", "Failed to update group member count: " + response.getMessage());
        }
    }
}