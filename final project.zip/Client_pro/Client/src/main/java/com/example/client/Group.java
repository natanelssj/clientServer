package com.example.client;

import javafx.collections.FXCollections;

import java.util.ArrayList;
import java.util.List;

public class Group {
    private Integer id;
    private String name;
    private List<String> members; // List of member names for compatibility
    private int memberCount = 0; // New field to store the number of members

    public Group(Integer id, String name) {
        this.id = id;
        this.name = name;
        this.members = new ArrayList<>();
        this.memberCount = 0; // Default to 0 members
    }

    public Group(String name) {
        this(0, name);
    }

    public Integer getId() { return id; }
    public String getName() { return name; }
    public List<String> getMembers() { return members; }
    public int getMemberCount() { return memberCount; } // New getter for member count

    public void setId(Integer id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setMembers(List<String> members) {
        this.members = members != null ? members : new ArrayList<>();
        this.memberCount = this.members.size(); // Sync memberCount with members list
    }
    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount >= 0 ? memberCount : 0; // Ensure non-negative count
    }

    @Override
    public String toString() {
        return "Group{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", members=" + members +
                ", memberCount=" + memberCount +
                '}';
    }
}